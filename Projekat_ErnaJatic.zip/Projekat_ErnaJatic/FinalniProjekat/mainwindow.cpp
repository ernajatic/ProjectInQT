#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSql>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QPixmap>
#include <QGraphicsPixmapItem>



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:\\Users\\WIN10\\Desktop\\Projekat_ErnaJatic\\FinalniProjekat\\ClickChargeEJ.db");

    if (db.open())
    {
        ui->setupUi(this);

        // Uspješna konekcija sa bazom

        qDebug() << "Konekcija sa bazom je uspješna.";
        model = new QSqlTableModel(this);
        model->setTable("Printeri");
        model->select();
        ui->ListaPrintera->setModel(model);

        QSqlQuery query;
        query.prepare("SELECT DISTINCT lokacija FROM Printeri");
        if (!query.exec()) {
            qDebug() << "Failed to execute query.";
            return;
        }
        ui->lokacijeBox->clear();
        while (query.next()) {
            QString location = query.value(0).toString();
            ui->lokacijeBox->addItem(location);
        }
        connect(ui->lokacijeBox, SIGNAL(currentTextChanged(const QString&)),
                this, SLOT(handleComboBoxSelection(const QString&)));
        connect(ui->ListaPrintera, SIGNAL(clicked(const QModelIndex&)),
                this, SLOT(handleTableViewClick(const QModelIndex&)));
    }
    else
    {
        //  Konekcija sa bazom neuspješna

        qDebug() << "Greška pri otvaranju baze: " << db.lastError().text();

                                                     return; //Izlazak iz funkcije
    }


}

MainWindow::~MainWindow()
{
    delete ui;
    delete model;
}

void MainWindow::handleComboBoxSelection(const QString& selectedItem)
{
    QString filter = QString("lokacija = '%1'").arg(selectedItem);
    model->setFilter(filter);
    ui->ListaPrintera->setModel(model);

    QString imagePath = "C:\\Users\\WIN10\\Desktop\\Projekat_ErnaJatic\\FinalniProjekat\\images\\"+ selectedItem +".jpg"; // Replace with the actual path to your image file

    QPixmap pixmap(imagePath);
    if (!pixmap.isNull()) {
                                                     QGraphicsScene* scene = new QGraphicsScene;
                                                     scene->addPixmap(pixmap);
                                                     ui->graphicsView->setScene(scene);
                                                     ui->graphicsView->fitInView(scene->sceneRect(), Qt::KeepAspectRatio);
    } else {
                                                     // Handle the case when loading the image fails
                                                     qDebug() << "Failed to load image:" << imagePath;
    }
    /*QString floorPlanImagePath = "C:\\Users\\WIN10\\Desktop\\Projekat_ErnaJatic\\FinalniProjekat\\images\\Ši Selo PJD Tuzla.jpg" ;

    QPixmap floorPlanImage(floorPlanImagePath);

    QGraphicsScene* scene = ui->graphicsView->scene(); // Replace 'graphicsView' with the actual name of your QGraphicsView
    scene->clear(); // Clear the scene before adding the new item

    QGraphicsPixmapItem* pixmapItem = scene->addPixmap(floorPlanImage);

    ui->graphicsView->fitInView(scene->sceneRect(), Qt::KeepAspectRatio); // Fit the view to the scene while maintaining the aspect ratio*/
}




void MainWindow::handleTableViewClick(const QModelIndex& index)
{
    if (index.isValid())
    {
        int column = 4; // Replace with the desired column index
        QString data = index.model()->data(index.sibling(index.row(), column)).toString();
                                                     // Process the data as needed
        qDebug() << "Clicked data:" << data;
    }
}

